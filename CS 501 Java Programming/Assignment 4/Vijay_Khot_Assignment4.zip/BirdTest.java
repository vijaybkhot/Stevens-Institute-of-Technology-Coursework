/*
Name: Vijay Khot
CWID: 20021838
*/
public class BirdTest {

    public static void main(String[] args) {

        Bird bird = new Bird();


        System.out.println("Input: bird.fly()");
        System.out.println("Output: " + bird.fly());
        System.out.println();
        System.out.println("Input: bird.move()");
        System.out.println("Output: " + bird.move());
    }
}
