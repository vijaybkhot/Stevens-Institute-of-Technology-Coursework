/*
Name: Vijay Khot
CWID: 20021838
*/
public interface Shape {


    public double area();

}
