/*
Name: Vijay Khot
CWID: 20021838
*/
public class AnimalTest {
    public static void main(String[] args) {
        // Create an instance of the Animal class
        Animal animal = new Animal(9, 45);
        Animal animal1 = new Animal();

        System.out.println("Input: animal.age");
        System.out.println("Output: " + animal.age);
        System.out.println();
        System.out.println("Input: animal.weight");
        System.out.println("Output: " + animal.weight);
        System.out.println();
        System.out.println("Input: animal.eat()");
        System.out.println("Output: " + animal.eat());
        System.out.println();
        System.out.println("Input: animal.move()");
        System.out.println("Output: " + animal.move());
        System.out.println();

        System.out.println("Input: animal1.age");
        System.out.println("Output: " + animal1.age);
        System.out.println();
        System.out.println("Input: animal1.weight");
        System.out.println("Output: " + animal1.weight);
        System.out.println();
        System.out.println("Input: animal1.eat()");
        System.out.println("Output: " + animal1.eat());
        System.out.println();
        System.out.println("Input: animal1.move()");
        System.out.println("Output: " + animal1.move());
        System.out.println();




    }
}
