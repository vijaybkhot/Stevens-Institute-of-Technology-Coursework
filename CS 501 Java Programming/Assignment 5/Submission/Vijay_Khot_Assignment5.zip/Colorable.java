/*
Name: Vijay Khot
CWID: 20021838
*/
// Create Interface named `Colorable` :
public interface Colorable {
    /**
     * @param color: The String color of the shape
     * @return: The assigned color of the shape
     */
    public abstract String fillColor(String color);

}
