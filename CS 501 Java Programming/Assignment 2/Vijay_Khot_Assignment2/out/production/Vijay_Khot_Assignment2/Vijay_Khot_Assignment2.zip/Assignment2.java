
/*
 * Assignment 2
 * Name : Vijay Khot
 * CWID : 20021838
 * */

public class Assignment2 {

    // Methods

    public static int[] findMinMax(int[] arr) {
        // Throw an illegal argument exception error if the input array is empty
        if (arr.length == 0) {
            throw new IllegalArgumentException("Array is empty.");
        }
        // Create two integer variables 'min' and 'max' to store respective values and assign them with the first element of the array
        int min = arr[0];
        int max = arr[0];
        // Iterate through all the elements of the array from the second element
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) { //If arr[i] is greater than max, reassign max with arr[i]
                max = arr[i];
            }
            if (arr[i] < min) {
                min = arr[i]; //If arr[i] is less than min, reassign min with arr[i]
            }
        }
        int[] finalMinMax = {min, max};// Create an array which holds 'min' and 'max' to return
        return finalMinMax; // Return the final array of min and max
    }


    public static int[] reverseInPlace(int[] arr) {
        // We need to iterate only through half of the elements of the array to interchange the position of each element
        for (int i = 0; i < (arr.length/2); i++) {
            int temp = arr[i]; //Make a copy of the 'i' element in the array
            arr[i] = arr[arr.length-i-1]; // assign the 'i' th element with 'length-i-1'th element
            arr[arr.length-i-1] = temp; // assign the 'length-i-1'th element with the copy value of the 'i'th element
        }
        return arr; //Return the reversed array
    }


    public static int sumOfDiagonal(int[][] matrix) {
        // TODO
        int sum = 0; //Initialize the 'sum' integer with zero
        // Iterate through each element of the input matrix
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                // As the input is a 3x3 matrix, diagonal elements have 'i' and 'j' equal. eg: 11, 22, 33
                if (i == j) {
                    sum += matrix[i][j]; // add the value of the diagonal element to the sum variable
                }
            }
        }
        return sum; // return the sum value
    }


    public static int[][] transposeMatrix(int[][] matrix) {
        // Transpose of a matrix means that an element with position [i][j] in one matrix changes to [j][i]
        // Initialize a transpose matrix. By interchanging the numbers of rows with columns and vice versa
        int[][] transpose = new int[matrix[0].length][matrix.length];
        //Iterate through each element of the matrix array
        for (int i= 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                transpose[j][i] = matrix[i][j]; // Reverse the position of 'i' and 'j' in transpose
            }
        }
        return transpose; // Return the transpose matrix
    }



    // Main function

    public static void main(String[] args) {


        // Tests for findMinMax
        int[] minMax = findMinMax(new int[] {9, 45, 21, 56, 78, 34, 25, 67, 99, 12});
        int[] minMax1 = findMinMax(new int[] {10, 5, 14, 3, 7});

        System.out.println("The minimum value is " + minMax[0]);
        System.out.println("The maximum value is " + minMax[1]);
        System.out.println("The minimum value is " + minMax1[0]);
        System.out.println("The maximum value is " + minMax1[1]);
        System.out.println();


        // Tests for reverseInPlace
        int[] reversedArray = reverseInPlace(new int[] {1, 2, 3, 4, 5});
        System.out.print("The reversed array is: ");
        for (int i = 0; i < reversedArray.length; i++) {
            System.out.print(reversedArray[i] + " ");
        }
        System.out.println();


        // Tests for sumOfDiagonal
        System.out.println();
        System.out.println(sumOfDiagonal(new int[][] {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}}));
        System.out.println(sumOfDiagonal(new int[][] {{10, 11, 12}, {13, 14, 15}, {16, 17, 18}}));
        System.out.println();


        // Tests for transposeMatrix
        int[][] transpose = transposeMatrix(new int[][] {{1, 2, 3}, {4, 5, 6}});
        System.out.println("The transpose of the input matrix is: ");
        for (int i = 0; i < transpose.length; i++) {
            for (int j = 0; j < transpose[0].length; j++) {
                System.out.print(transpose[i][j] + " ");
            }
            System.out.println();
        }
    }
}
